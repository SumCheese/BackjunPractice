package Backjun_practice_231124;

//아래 예제와 같이 고양이를 출력하시오.

public class Num_10171 {
	public static void main(String[] args) {
		System.out.println("\\    /\\");
		System.out.println(" )  ( ')");
		System.out.println("(  /  )");
		System.out.println(" \\(__)|");
		
	}

}

// 큰 따옴표와 백슬래쉬는 쓸 때 백슬래쉬를 더해준다.