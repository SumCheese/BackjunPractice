package Backjun_practice_231124;

//두 자연수 A와 B가 주어진다. 이때, A+B, A-B, A*B, A/B(몫), A%B(나머지)를 출력하는 프로그램을 작성하시오. 

import java.util.*;

public class Num_10869 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int A = sc.nextInt();
		int B = sc.nextInt();
		
		sc.close();
		
		int sum = A+B;
		int sub = A-B;
		int multi = A*B;
		int divi = A/B;
		int remain = A%B;
		
		System.out.println(sum);
		System.out.println(sub);
		System.out.println(multi);
		System.out.println(divi);
		System.out.println(remain);
		}

}
