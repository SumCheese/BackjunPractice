package Backjun_practice_231124;

//꼬마 정민이는 이제 A + B 정도는 쉽게 계산할 수 있다. 이제 A + B + C를 계산할 차례이다!

import java.util.*;

public class Num_11382 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int A = sc.nextInt();
		int B = sc.nextInt();
		int C=  sc.nextInt();
		
		sc.close();
		
		System.out.println(A+B+C);
	}
}
