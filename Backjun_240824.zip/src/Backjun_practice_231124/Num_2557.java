package Backjun_practice_231124;

//Hello World!를 출력하시오.

public class Num_2557 {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
