package Backjun_practice_231124;

import java.util.*;

public class Num_2588 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int A = sc.nextInt();
		int B = sc.nextInt();
		
		sc.close();
		
		int oneOfB = B%10;
		int tenOfB = (B/10)%10;
		int hundOfB = (B/100);
		
		System.out.println(A*oneOfB);
		System.out.println(A*tenOfB);
		System.out.println(A*hundOfB);
		System.out.println(A*B);
	}

}
