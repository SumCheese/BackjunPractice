package Backjun_practice_231205;

import java.util.*;

public class Num_2480 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		sc.close();
		
		int money;
		
		if(a == b) {
			if( a == c) {
				money = 10000 + a*1000;
			}
			else {
				money = 1000 + a*100;
			}
			
		}
		else if(a == c) {
			if ( a == b) {
				money = 10000+ a*1000;
			}
			else { 
				money = 1000 + a*100;
			}
		}
		else {
			if(b == c) { // a =! b== c
				money = 1000 +(b*100);
			}
			else { // a =! b =! c
				if(a > b) {
					if ( a > c) {
						money = a * 100;
					}
					else {
						money = c * 100;
					}
				}
				else if (a > c) {
					if( a > b) {
						money = a * 100;
					}
					else {
						money = b * 100;
					}
				}
				else {
					if (b > c ) {
						money = b *100;
					}
					else {
						money = c *100;
					}
				}
			}
		}
		
		
		System.out.println(money);
	}

}
