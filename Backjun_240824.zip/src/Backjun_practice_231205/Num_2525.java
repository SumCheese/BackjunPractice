package Backjun_practice_231205;

import java.util.*;

public class Num_2525 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int hour = sc.nextInt();
		int min = sc.nextInt();
		int cookingTime = sc.nextInt();
		
		sc.close();
		
		int cookingTime_hour = hour+((min+cookingTime)/60);
		int cookingTime_min = (min+cookingTime)%60;
		
		if(cookingTime_hour >= 24) {
			cookingTime_hour = cookingTime_hour % 24;
		}
		
		System.out.println(cookingTime_hour +" "+cookingTime_min);
		
	}

}
