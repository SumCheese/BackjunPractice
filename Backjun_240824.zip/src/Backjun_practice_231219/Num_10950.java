package Backjun_practice_231219;

import java.util.*;

public class Num_10950 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		int num = sc.nextInt();
		int[] number = new int[num];
		
		for(int i = 0; i<num;i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			int sum = a+b;
			number[i]= sum;
		}
		
		sc.close();
		
		for(int i = 0; i<num; i++) {
			System.out.println(number[i]);
		}
	}

}
